﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Perceptron_R_ONTOLAN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cbInput1.Items.AddRange(new string[] { "0", "1" });
            cbInput2.Items.AddRange(new string[] { "0", "1" });
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cbInput1.SelectedItem == null || cbInput2.SelectedItem == null)
            {
                MessageBox.Show("Please select values for both inputs.");
                return;
            }

            int input1 = int.Parse(cbInput1.SelectedItem.ToString());
            int input2 = int.Parse(cbInput2.SelectedItem.ToString());

            int output = Perceptron(input1, input2);
            tbOutput.Text = output.ToString();
        }
        private int Perceptron(int x1, int x2)
        {
            int w1 = 1, w2 = 1, threshold = 1;
            int sum = (x1 * w1) + (x2 * w2);

            return sum >= threshold ? 1 : 0; 
        }
    }
}
