﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Perceptron_R_ONTOLAN
{
    public partial class Form1 : Form
    {
        private double weight1 = 0.0;
        private double weight2 = 0.0;
        private double bias = 0.0;
        private double learningRate = 0.1;
        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.AddRange(new string[] { "0", "1" });
            comboBox2.Items.AddRange(new string[] { "0", "1" });
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Please select values for both inputs.");
                return;
            }

            int input1 = int.Parse(comboBox1.SelectedItem.ToString());
            int input2 = int.Parse(comboBox2.SelectedItem.ToString());

            int output = Predict(input1, input2);
            textBox1.Text = output.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TrainPerceptron();
            MessageBox.Show("Perceptron trained successfully for OR function!");
        }

        private int Predict(int x1, int x2)
        {
            double sum = (x1 * weight1) + (x2 * weight2) + bias;
            return sum >= 0 ? 1 : 0; // Step activation function
        }

        private void TrainPerceptron()
        {
            // Training data for an OR gate
            int[,] inputs = { { 0, 0 }, { 0, 1 }, { 1, 0 }, { 1, 1 } };
            int[] outputs = { 0, 1, 1, 1 }; // OR gate expected output

            bool errorExists;
            int epochs = 100; // Limit training to avoid infinite loops

            for (int i = 0; i < epochs; i++)
            {
                errorExists = false;

                for (int j = 0; j < inputs.GetLength(0); j++)
                {
                    int x1 = inputs[j, 0];
                    int x2 = inputs[j, 1];
                    int expected = outputs[j];

                    int predicted = Predict(x1, x2);
                    int error = expected - predicted;

                    if (error != 0)
                    {
                        weight1 += learningRate * error * x1;
                        weight2 += learningRate * error * x2;
                        bias += learningRate * error;
                        errorExists = true;
                    }
                }

                if (!errorExists) break; // Stop if no errors
            }
        }
    }
}
